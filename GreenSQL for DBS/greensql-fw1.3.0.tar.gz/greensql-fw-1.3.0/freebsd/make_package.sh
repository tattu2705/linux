pkg_create -v -d pkg-descr -f pkg-plist -i pkg-install -S . -p /usr/local/ greensql-fw.tbz
