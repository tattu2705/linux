MySQL dependent code will be in this directory.
