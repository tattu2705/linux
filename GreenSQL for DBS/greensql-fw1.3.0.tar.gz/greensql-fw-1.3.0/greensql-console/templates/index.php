<?php
header("Location: ../");
?>
